const jwt = require('jsonwebtoken');
const config = require('../db/authconfig');


verifyToke= (req,res,next) => {
    let token = req.headers["x-access-token"];
    if(!token){
      return res.status(401).json({message: "Token hiányzik!"});
    } 
    else{
      jwt.verify(token, config.secret, (err,decoded) => {
        if(err){
         return res.status(401).send({message: "Érvénytelen token"});
        }

        else{
          req.userParams=decoded;
        }

      });
      next();
    }
}

module.exports={verifyToke};