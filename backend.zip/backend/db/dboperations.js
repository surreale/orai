var config = require("./dbconfig");
const sql = require('mysql2/promise');

let pool = sql.createPool(config);



async function selectUser(email,password){
    try{
        const [rows] = await pool.query('select * from users where email=? and password=SHA2(?,256)', [email, password]);
                        
        return rows;
    }
    catch(error){
        throw error;
    }
}



async function selectTermek() {
   try{ 
    const [rows] = await pool.query('select * from termek');
    return rows;
   }
   catch(error){
    throw error;
   } 
}

async function selectTermekById(id) {
    try{ 
     const [rows] = await pool.query('select * from termek where azonosito=?',[id]);
     return rows;
    }
    catch(error){
     throw error;
    } 
 }

async function insertTermek(termek,ar) {
    try{
        const [rows] = await pool.query('insert into termek (termek,ar) values (?,?)',
                        [termek,ar]);
        return rows;
    }
    catch(error){
        throw error;
    }
}

async function deleteTermek(id) {
    try{
        const [rows] = await pool.query('delete from termek where azonosito=?',[id]);
        return rows;
    }
    catch(error){
        throw error;
    }
}


async function updateTermek(id,termek,ar) {
    try{
        const [rows] = await pool.query('update termek set termek=?, ar=? where azonosito=?',
                        [termek,ar,id]);
        return rows;
    }
    catch(error){
        throw error;
    }
}

async function filterTermek(nev) {
    try{
        const [rows] = await pool.query('select * from termek where termek like ?', [nev]);
        return rows;
    }
    catch(error){
        throw error;
    }
}

module.exports = {
    selectUser,
    selectTermek,
    selectTermekById,
    insertTermek,
    deleteTermek,
    updateTermek,
    filterTermek
    
}
