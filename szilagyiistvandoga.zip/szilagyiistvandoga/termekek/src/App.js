import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import axios from 'axios';  
import { useState, useEffect } from 'react';
import {Container, Row, Col, Card, Button} from 'react-bootstrap';


function App() {
  const [data, setdata] = useState([]);
  const [errormsg, seterrormsg] = useState([""]);

  async function fechData(){
    try{
      const valasz = await axios.get("https://dummyjson.com/products");
      setdata(valasz.data.products);
    }
    catch(error){
      seterrormsg(error);
    }
    
  }

  useEffect(()=>{
    fechData();
  }, []);


  return (
    <div>

    <h1>Terméklistánk</h1>
    {
    <Container fluid>
      <Row>

    {
    data.map((adat) => (
      <Col xs={12} sm={6} md={4} lg={2} key={adat.id} className="d-flex justfy-content-center my-3">
      <Card style={{ width: '18rem' }}>
      <Card.Title>{adat.brand}</Card.Title>
      <Card.Img variant="top" src={adat.thumbnail} />
      <Card.Body>
      <Card.Title> {adat.category} </Card.Title>
      <Card.Title>{adat.title}</Card.Title>
      <Card.Title>{"Ár: "+adat.price+" $"}</Card.Title>
      <Card.Text>{adat.description}</Card.Text>
      <Button variant="primary">Kosárba</Button>
      </Card.Body>
    </Card>
    </Col>) )
    }
    </Row>
    </Container>
    }
    </div>
  );
}

export default App;
