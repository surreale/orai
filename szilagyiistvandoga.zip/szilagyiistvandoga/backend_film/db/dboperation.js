var config = require('./dbconfig');
const sql= require("mysql2/promise");
let pool = sql.createPool(config);



async function selectFilm(){
    try{
        const [rows] = await pool.query('select * from film');
        return rows;
    }

    catch(error){
        throw error;
    }
 }

 async function insertFilm(data)
 {
    try{
        const [rows] = await pool.query('insert into film (rendezo, cim, ev, nyelv, hossz) values (?,?,?,?,?) ', [data.rendezo, data.cim, data.ev, data.nyelv, data.hossz]);
        return rows;
    }

    catch(error){
        throw error;
    }
 }

 async function deleteFilm(id){
    try{
        const [rows] = await pool.query('delete from film where id =?', [id]);
        return rows;
    }

    catch(error){
        throw error;
    }
 }



 module.exports = {
    selectFilm,
    insertFilm,
    deleteFilm,
    
 };