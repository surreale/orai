var express = require('express');
var router = express.Router();
var Db= require('../db/dboperation');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/api/film',async function(req, res) {
  const film= await Db.selectFilm();
  res.json(film);
});

router.post('/api/film/:data', async function(req, res){
  try{
    let id=req.params.id;
  const film= await Db.insertFilm(data);
  if(film.length == 0){
    res.status(400).json({message: "Hiányos adatok"});//Not found
  }
  else{res.json(eredmeny);}
  }
  
  catch(error){
    res.status(500).json({hiba: "Belső szerver hiba"});//Internal server error
  }
 
})

router.delete('/api/film/:id', async function(req, res){
  let id=req.params.id;
  const eredmeny = await Db.deleteFilm(id);
  res.json(eredmeny);
})

module.exports = router;


