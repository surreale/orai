var express = require('express');
var router = express.Router();
var Db = require('../db/dboperations');

router.get('/', async function(req, res, next) {
 try{
  const termek = await Db.selectTermek();
  res.json(termek);
 }
 catch(error){
  console.log(error);
//  res.status(500).send('Szever hiba!');
res.status(500).json({
    message: 'Szerver hiba!',
    error: error.message || error,  
  });
 }
});


router.post('/', async function(req, res) {
  try{
   const {nev,ar,szin} = req.body;
   if(!nev || !ar || !szin){
    return res.status(400).json({message: 'Kérjük, adja meg a termék nevét, árát és színét!'})
   }
   const result = await Db.insertTermek (nev,ar,szin)
   res.status(201).json(result);
  }
  catch(error){
   console.log(error);
 
 
  }
 });


 router.delete('/:id', async function(req, res) {
  try{
   const id = req.params.id;
   
   const result = await Db.deleteTermek (id)

   if(result.affectedRows ===0 ){
    res.status(404).json({message: "nincs ilyen termék"})
   }
   else{
    res.json(result)
   }
   
  }
  catch(error){
   console.log(error);{
    res.status(500).json({
      message: 'Szerver hiba!',
      error: error.message || error,
    })

   }
 
 
  }
 });
module.exports = router;
