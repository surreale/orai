const config = require('./dbconfig');
const sql = require('mysql2/promise');

let pool = sql.createPool(config);

async function selectTermek() {
    try{ 
     const [rows] = await pool.query('select * from termek');
     return rows;
    }
    catch(error){
     throw error;
    } 
 }



 async function insertTermek(nev, ar, szin) {
    try{ 
     const [rows] = await pool.query('insert into termek (nev,ar,szin) values (?,?,?)', [nev,ar,szin]);
     return rows;
    }
    catch(error){
     throw error;
    } 
 }

 async function deleteTermek(id) {
    try{ 
     const [rows] = await pool.query('delete from termek where id=? ', [id]);
     return rows;
    }
    catch(error){
     throw error;
    } 
 }

module.exports = {
    selectTermek,
    insertTermek,
    deleteTermek
}