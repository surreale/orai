export default function NotFound(){
    return(
        <div className="container">
            <h1>404 Not Found</h1>
            <p>Nincs Ilyen oldal</p>
        </div>
    )
}