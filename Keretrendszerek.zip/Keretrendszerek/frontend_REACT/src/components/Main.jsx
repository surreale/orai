export default function Main(){
    return(
        <div className="container">
            <h1>Welcome to the Main Component</h1>
            <p>Tihis</p>
        </div>
    )
}