import axios from "axios";
import { useEffect, useState } from "react";




export default function Lista(){
    const [data, setData]= useState([]);

    async function fetchData(){
        try{
            const response= await axios.get("https://jsonplaceholder.typicode.com/posts");
            setData(response.data);
        } catch(error){
            console.error("Error fetching data:", error);
        }

    }
    useEffect(() => {
        fetchData();
    }, [])
    return(
        <div className="container">
            <h1>Lista</h1>
            {data.map((item)=> (
                <div key={item.id} className="card mb-3">
                    <div className="card-body">
                        <h5 className="card-title">{item.title}</h5>
                        <p className="card-text">{item.body}</p>
                </div>
                </div>
            ))}

        </div>
    );
}