import { Link } from "react-router-dom";
import logo from "../assests/vor.png"

export default function About(){
    return(
        <div className="container">
            <h1>Welcome to the About Component</h1>
            <p>Tihis</p>
            <img src={logo} alt="Logo"></img>
            <Link className="button-link" to="/">Vissza a főoldalra</Link>
        </div>
    )
}