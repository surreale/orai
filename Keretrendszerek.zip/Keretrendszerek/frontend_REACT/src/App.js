import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import {BrowserRouter as Router, Routes, Route, Link} from 'react-router-dom';
import Main from './components/Main'
import About from './components/About'
import NotFound from './components/NotFound';
import Lista from './components/Lista'

function App() {
  return (
    <>
    <Router>
      <nav>
        <Link className="button-link" to="/">Main</Link>
        <Link className="button-link" to="/about">About</Link>
        <Link className="button-link" to="/lista">Lista</Link>
      </nav>
     <Routes>
      <Route path="/" element={<Main/>}/>
      <Route path="/about" element={<About/>}/>
      <Route path="*" element={<NotFound/>}/>
      <Route path="/lista" element={<Lista/>}/>
     </Routes>
    </Router>
    </>
  );
}

export default App;
