export default function Footer(){
return(
    <footer className="bg-light text-center text-lg-start">
    <div className="container p-4">
      <div className="row">
        <div className="col-lg-4 col-md-6 mb-4 mb-md-0">
          <h5 className="text-uppercase">Rólunk</h5>
          <p>
          Folyton megújuló iskolánk ma is szeretettel és odafigyeléssel várja volt, mostani és leendő diákjait.
          </p>
        </div>

        <div className="col-lg-4 col-md-6 mb-4 mb-md-0">
          <h5 className="text-uppercase">Szolgáltatások</h5>
          <ul className="list-unstyled">
            <li><a href="#!" className="text-dark">Web Design</a></li>
            <li><a href="#!" className="text-dark">Development</a></li>
            <li><a href="#!" className="text-dark">Hosting</a></li>
          </ul>
        </div>

        <div className="col-lg-4 col-md-6 mb-4 mb-md-0">
          <h5 className="text-uppercase">Contact</h5>
          <p>
            Mezőtúr Dózsa György út 17.<br />
            Email: info@telekimezotur.hu<br />
            Phone: +123 456 789
          </p>
        </div>
      </div>
    </div>

    <div className="text-center p-3 bg-dark text-white">
      &copy; 2025 Teleki Website. Minden jog fenntartva.
    </div>
  </footer>
)
}