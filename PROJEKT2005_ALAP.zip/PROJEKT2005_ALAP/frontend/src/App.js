import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Menu from './components/Menu';
import Footer from './components/Footer';
import filmImage from './assets/film.jpg';

function App() {
  const appStyle = {
    display: 'flex',
    flexDirection: 'column',
    minHeight: '100vh', // A teljes képernyő magasságának beállítása
  };
  const mainStyle = {
    backgroundImage: `url(${filmImage})`,
    backgroundSize: 'cover', // A kép teljesen kitölti a rendelkezésre álló teret, a képarány megtartásával.
    backgroundPosition: 'center', // A kép középre igazítva jelenik meg.
    backgroundRepeat: 'no-repeat', // A kép nem ismétlődik.
    flex: '1', // A fő tartalom kitölti a fennmaradó helyet
    padding: '20px',
  };

  return (
    <div style={appStyle}>
      <Menu />
      <main style={mainStyle}>
       <h1 style={{ color: 'white', textAlign: 'center' }}>
        Vizsga frontend projekt
       </h1>

      </main>
      <Footer />
    </div>
  );
}

export default App;
