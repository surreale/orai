﻿using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BarlangokGUI
{
    
    public partial class MainWindow : Window
    {

            List<Barlang> adatok = new List<Barlang>();
        int hosszusag = 0;
        int melyseg = 0;
        int hely = 0;
        public MainWindow()
        {
            InitializeComponent();

            
            using (StreamReader sr = new StreamReader("barlangok.txt"))
            {
                sr.ReadLine();
                string sor;
                while ((sor = sr.ReadLine()) != null)
                {
                    adatok.Add(new Barlang(sor));
                }
            }
        }

        private void keres_Click(object sender, RoutedEventArgs e)
        {
            int azonosito = Convert.ToInt32(azon.Text);
            bool van = false;
            for (int i = 0; i < adatok.Count(); i++) 
            {
                if (adatok[i].Azon == azonosito) 
                {
                    nev.Content = $"Barlang neve: {adatok[i].Nev}";
                    hossz.Text= Convert.ToString(adatok[i].Hossz);
                    hosszusag= adatok[i].Hossz;
                    mely.Text= Convert.ToString(adatok[i].Melyseg);
                    melyseg = adatok[i].Melyseg;
                    ment.IsEnabled = true;
                    van= true;

                    break;
                }
            }
            if (!van)
            {
                MessageBox.Show("Ezzel az azonosítóval nem létezik ilyen barlang");
                azon.Text = "";
                nev.Content = $"Barlang neve:";
                hossz.Text = ("");
                mely.Text = ("");
                ment.IsEnabled = false;
            }
        }

        private void ment_Click(object sender, RoutedEventArgs e)
        {
            int akthosszusag = Convert.ToInt32(hossz.Text);
            int aktmelyseg = Convert.ToInt32(mely.Text);
            if (hosszusag > akthosszusag) MessageBox.Show($"A hossz nem lehet kisebb a korább értékénél {akthosszusag}");
            else adatok[hely].Hossz=akthosszusag;
            if (melyseg > aktmelyseg) MessageBox.Show($"A mélység nem lehet kisebb a korább értéknél {aktmelyseg}");
            else adatok[hely].Melyseg=aktmelyseg;
            azon.Text = "";
            nev.Content = $"Barlang neve:";
            hossz.Text = "";
            mely.Text = "";

        }
    }
}