﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Barlangok
{
    class Barlang
    {
        private int melyseg = 0;
        private int hossz = 0;

        public int Azon { get; private set; }
        public string Nev { get; private set; }

        public int Hossz
        {
            get
            {
                return hossz;
            }
            set
            {
                if (value >= hossz)
                {
                    hossz = value;
                }
            }
        }

        public int Melyseg
        {
            get
            {
                return melyseg;
            }
            set
            {
                if (value >= melyseg)
                {
                    melyseg = value;
                }
            }
        }

        public string Telepules { get; private set; }
        public string Vedettseg { get; private set; }

        public Barlang(string sor)
        {
            string[] m = sor.Split(';');
            Azon = int.Parse(m[0]);
            Nev = m[1];
            Hossz = int.Parse(m[2]);
            Melyseg = int.Parse(m[3]);
            Telepules = m[4];
            Vedettseg = m[5];
        }

        public override string ToString()
        {
            return $"\tAzon: {Azon}\n\tNév: {Nev}\n\tHossz: {Hossz} m\n\tMélység: {Melyseg} m\n\tTelepülés: {Telepules}";
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            List<Barlang> adatok = new List<Barlang>();
            using (StreamReader sr = new StreamReader("barlangok.txt"))
            {
                sr.ReadLine();
                string sor;
                while ((sor = sr.ReadLine()) != null)
                {
                    adatok.Add(new Barlang(sor));
                }
            }
            //4.feladat
            int db = adatok.Count();
            Console.WriteLine($"4.feladat: Barlangok száma: {db}");

            //5.feladat
            double melyseg = 0;
            double dbb = 0;
            for (int i = 0; i < db; i++)
            {
                if (adatok[i].Telepules.Contains("Miskolc"))
                {
                    melyseg += adatok[i].Melyseg;
                    dbb++;
                }
            }
            Console.WriteLine($"5.feladat: az átlagos mélység: {melyseg / dbb:F3} m");

            //6.feladat
            Console.Write("6.feladat: Kérem a védettségi szintet:  ");
            string szint = Console.ReadLine();
            bool van = false;
            int leghosszabb = 0;
            int sorszam= 0;
            for (int i = 0; i < db; i++)
            {
                if (adatok[i].Vedettseg == szint)
                {
                    if (adatok[i].Hossz > leghosszabb)
                    {
                        leghosszabb = adatok[i].Hossz;
                        sorszam = i;
                    }
                    van = true;
                }
                
            }
            if (van) 
            { 
                Console.WriteLine($"\tAzon: {adatok[sorszam].Azon}");
                Console.WriteLine($"\tNév: {adatok[sorszam].Nev}");
                Console.WriteLine($"\tHossz: {adatok[sorszam].Hossz}");
                Console.WriteLine($"\tMélység: {adatok[sorszam].Melyseg}");
                Console.WriteLine($"\tTelepülés: {adatok[sorszam].Telepules}");
            }
            else
            {
                Console.WriteLine("Nincs ilyen védettségi szint!");
            }
            //7.feladaat
            Console.WriteLine("7. feladat: Statisztika");
            List<string> szintek = new List<string>();
            for (int i = 0; i < db; i++) 
            {
                if (!szintek.Contains(adatok[i].Vedettseg))
                {
                    szintek.Add(adatok[i].Vedettseg);
                }
            }

            
            for (int i = 0; i < szintek.Count; i++)
            {
                int aktdb= 0;
                for (int j = 0; j < db; j++)
                {
                    if (szintek[i] == adatok[j].Vedettseg)
                    {
                        aktdb ++;
                    }

                }
                
                int hianyzo= 29- szintek[i].Length;
                Console.Write($"\t{szintek[i]}:");
                for (int k = 0; k < hianyzo; k++) 
                {
                    Console.Write("-");
                }
                Console.WriteLine($"> {aktdb} db");
            }

            
            Console.ReadKey();
        }
    }
}
