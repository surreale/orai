﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace nepesseg
{
    class Orszag
    {
        public string Orszagnev { get; private set; }
        public int Terulet { get; private set; }
        public int Nepesseg { get; private set; }
        public string Fovaros { get; private set; }
        public int FovarosNepesseg { get; private set; }

        public Orszag(string orszagnev, int terulet, int nepesseg, string fovaros, int fovarosNepesseg)
        {
            Orszagnev = orszagnev;
            Terulet = terulet;
            Nepesseg = nepesseg;
            Fovaros = fovaros;
            FovarosNepesseg = fovarosNepesseg;
        }

        public Orszag(string sor)
        {
            string[] m = sor.Split(';');
            Orszagnev = m[0];
            Terulet= int.Parse(m[1]);

            string nep = m[2];
            if (nep.EndsWith("g"))
            {
                nep = nep.Replace("g", "");

            }

            Nepesseg= int.Parse(nep);
            Fovaros = m[3];
            FovarosNepesseg= int.Parse(m[4]);
        }

        public override string ToString()
        {
            return "";
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            List<Orszag> adatok = new List<Orszag>();
            using (StreamReader sr = new StreamReader("adatok-utf8.txt"))
            {
                sr.ReadLine();
                string sor;
                while ((sor = sr.ReadLine()) != null)
                {
                    adatok.Add(new Orszag(sor));
                }
            }
            //4.feladat
            int db = adatok.Count();
            Console.WriteLine("4. feladat");
            Console.WriteLine($"A beolvasott országok száma: {db}.");
            

            //5.feladat
            Console.WriteLine("\n5. feladat");
            for (int i = 0; i < db; i++)
            {
                if (adatok[i].Orszagnev == "Kína")
                {
                    int nepsuruseg = (int) Math.Round((double)adatok[i].Nepesseg / adatok[i].Terulet,MidpointRounding.AwayFromZero );
                    
                    Console.WriteLine($"Kína népsűrűsége: {nepsuruseg} fő/km^2.");
                    break;
                }
            }

            //6. feladat
            int nepindia = 0;
            int nepkina = 0;
            for (int i = 0; i < db; i++) 
            {
                if (adatok[i].Orszagnev == "India")
                {
                    nepindia= adatok[i].Nepesseg;
                    break;
                }
            }
            for (int i = 0; i < db; i++)
            {
                if (adatok[i].Orszagnev == "Kína")
                {
                    nepkina = adatok[i].Nepesseg;
                    break;
                }
            }

            int nepminus = nepkina - nepindia;
            Console.WriteLine("\n6. feladat");
            Console.WriteLine($"Kínában a lakosság {nepminus} fővel volt több.");
            Console.ReadLine();
        }
    }
}
