var express = require('express');
var router = express.Router();
var Db= require('../db/dboperations');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});



router.get('/megyek', async function(req, res, ) {
  //res.send('Megyék......');
  const megyek = await Db.selectMegye();
  res.json(megyek);
});

router.get('/megyek/:id', async function(req, res){
  let id=req.params.id;
  const megye = await Db.selectMegyeId(id);
  console.log("hiba", megye.length);
  if(megye.lenght == 0){ 
    console.log("hiba2",megye.lenght)
    res.status(404).json(megye);
  }
  else{
    res.json(megye);
  }
  
})

router.delete('/megyek/:id', async function(req, res){
  let id=req.params.id;
  const eredmeny = await Db.deleteMegye(id);
  res.json(eredmeny);
})

router.post('/megyek', async function(req, res){
  let data = req.body;
  const eredmeny = await Db.insertMegye(data);
  res.json(eredmeny);
})
module.exports = router;
