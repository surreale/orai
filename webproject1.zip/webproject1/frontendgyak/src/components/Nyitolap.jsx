import { Link } from "react-router-dom";
import { Button } from 'react-bootstrap';

export default function Nyitolap() {
    return (
        <>
            <h2>Gyakorlás nyitólapja</h2>
            <Button as={Link} to="/termeklista" variant="primary">Terméklista</Button>

        </>
    )
}