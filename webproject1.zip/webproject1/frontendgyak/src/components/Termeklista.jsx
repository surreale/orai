import { Link } from "react-router-dom";
import { Button, Card, Container, Row, Col } from 'react-bootstrap';
import axios from 'axios';
import { useState, useEffect } from "react";


export default function Termeklista() {

    const [data, setData] = useState([]);
    const [msg, setMsg] = useState('');

    async function fethData() {
        try{
            const valasz = await axios.get('http://localhost:8080/termek');
        setData(valasz.data);
        }
        catch(error){
            setMsg(error.message);  
        }
    }

    // A komponens létrejöttekor fut le
    useEffect( ()=>{
        fethData();
    }, [] );

    return (
        <>
            <h1>Terméklista</h1>
            {msg && <div>{msg}</div>}
            {
                <Container> 
                    <Row>
            {data.map( adat => (
                    <Col xs={12} sm={6} md={4} lg={3} key={adat.azonosito} className="d-flex justify-content-center my-3">
                    <Card style={{width: '18rem'}}>
                    <Card.Img variant= "top" src={'http://localhost:8080/images/'+adat.kepnev }/>
                    <Card.Body>
                        <Card.Title>{adat.termek}</Card.Title>
                        <Card.Subtitle className="mb-2 text-muted">Ár: {adat.ar}</Card.Subtitle>
                        <Card.Text>
                           
                        </Card.Text>
                        <Button variant="primary" >Kosárba</Button>
                    </Card.Body>
                    </Card></Col>
                ) )
            }
                </Row>
                </Container>
            }
            <Button as={Link} to="/" variant="primary">Vissza</Button>
        </>
    )
}