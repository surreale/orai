const mysql = require('mysql2/promise');

const pool = mysql.createPool({
    host: 'localhost',
    user: 'root',   // Az adatbázis felhasználóneve
    password: 'root',   // Az adatbázis jelszava
    database: 'sportshop',   // Az adatbázis neve
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
    port: 3306   // Az adatbázis szerver portja
});

module.exports = pool;
