module.exports ={
    secret: "teleki-secret-key"
}