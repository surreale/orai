var express = require('express');
var router = express.Router();
var Db = require('../db/dboperations');

// Teljes lista 
router.get('/', async function (req, res, next) {
  try {
    const termekek = await Db.selectTermek();
    res.json(termekek);
  }
  catch (error) {
    res.status(500).json({ error: error });
  }
});

// Szűrt lista   http://localhost:3000/termek?nev=baseball
router.get('/filter', async function (req, res, next) {
  try {
    const nev = '%'+req.query.nev+'%';
    console.log(nev);
    const termekek = await Db.filterTermek(nev);
    res.json(termekek);
  }
  catch (error) {
    res.status(500).json({ error: error });
  }
});

// Egy termék  FIGYELEM!!! : /filter -> azonosito=filter
router.get('/:azonosito', async function (req, res, next) {
  try {
    const id = req.params.azonosito;
    const termek = await Db.selectTermekById(id);
    if (termek.length == 0) { //nincs ilyen termék
      res.status(404).json({ message: 'Nincs ilyen termék' })
    }
    else {
      res.json(termek);
    }
  }
  catch (error) {
    res.status(500).json({ error: error });
  }
});

// Új termék felvitele
router.post('/', async function (req, res, next) {
  let adat = req.body;
  try {
    if (!adat.ar || !adat.termek) {
      res.status(400).json({ message: "Hiányos adatok!" });
      return;
    }

    const valasz = await Db.insertTermek(adat.termek, adat.ar);
    res.json(valasz);
  }
  catch (error) {
    res.status(500).json({ "hiba": error });
  }
});

// Termék törlése
router.delete('/:id', async function (req, res, next) {
  try {
    let id = req.params.id;
    const valasz = await Db.deleteTermek(id);
    if (valasz.affectedRows === 0) { // nem volt törlés
      res.status(404).json({ message: "Nincs ilyen termék" })
    }
    else {
      res.json(valasz);
    }
  }
  catch (error) {
    res.status(500).json({ "hiba": error });
  }
});

// Termék módosítása
router.put('/:id', async function (req, res, next) {
  try {
    if (!req.body.ar || !req.body.termek) {
      res.status(400).json({ message: "Hiányos adatok!" });
      return;
    }
    let id = req.params.id;
    let valasz = await Db.updateTermek(id, req.body.termek, req.body.ar);
    if (valasz.affectedRows === 0) { // nincs ilyen
      res.status(404).json({ message: "Nincs ilyen termék-"+id })
    }
    else {
      res.json(valasz);
    }
  }
  catch (error) {
    res.status(500).json({ "hiba": error });
  }
})

module.exports = router;