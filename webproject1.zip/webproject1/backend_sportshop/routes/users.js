var express = require('express');
var router = express.Router();
const Db = require('../db/dboperations'); 
const jwt = require('jsonwebtoken');
const config = require('../db/authconfig');
const auth = require('../middleware/auth');

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');

});
//400 Bad request    hiányos adatok érvénytelen üzenet, 401 Unauthorized sikertelen hitelesítés

router.post('/login', async (req, res) => {
  try {
      const { email, password } = req.body;
      if (!email || !password) {
          return res.status(400).json({ message: "Hiányos adatok!" });
      }

      const user = await Db.selectUser(email, password);
      if (user.length === 0) {
          return res.status(401).json({ message: "Sikertelen hitelesítés!" });
      }

      const token = jwt.sign({ id: user[0].id, email: user[0].email, role: user[0].role }, config.secret, { expiresIn: '1h' });

      res.json({ token });
  } catch (error) {
      res.status(500).json({ error: error.message });
  }
});

  router.get('/userprofil', (req,res) => {
    let token = req.headers["x-access-token"];
    if(!token){
      return res.status(401).json({message: "Token hiányzik!"});
    } 
    else{
      jwt.verify(token, config.secret, (err,decoded) => {
        if(err){
          res.status(401).send({message: "Érvénytelen token"});
        }

        else{
          console.log('Kiadva: '+ new Date(1000*decoded.iat).toLocaleString());
          console.log('Kiadva: '+ new Date(1000*decoded.exp).toLocaleString());
          res.send(decoded);
        }

      });
    }
    //res.send('User profil adatok');
  })

  router.get('/test', [auth.verifyToke],(req, res) => {
    res.send("védett oldal")
  });



module.exports = router;
