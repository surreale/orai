var express = require('express');
var router = express.Router();
var Db= require('../db/dboperation');


/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/api/megye',async function(req, res) {
  const megyek= await Db.selectMegye();
  res.json(megyek);
});
router.get('/api/megye/:id',async function(req, res){
  try{

    let id=req.params.id;
  const megyek= await Db.selectMegyeId(id);
  if(megyek.length == 0){
    res.status(404).json({hiba: "A megadott id-val nem található megye"});//Not found
  }
  else{
    res.json(megyek);
  }
  
  }
  catch(error){
    res.status(500).json({hiba: "Belső szerver hiba"});//Internal server error
  }
  
});

module.exports = router;
