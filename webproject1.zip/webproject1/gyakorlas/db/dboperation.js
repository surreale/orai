var config = require('./dbconfig');
const sql= require("mysql2/promise");
let pool = sql.createPool(config);

async function selectMegye(){
    try{
        const [rows] = await pool.query('select * from megye');
        return rows;
    }

    catch(error){
        throw error;
    }
 }

 async function selectMegyeId(id){
    try{
        const [rows] = await pool.query('select * from megye where cty_id =?', [id]);
        return rows;
    }

    catch(error){
        throw error;
    }
 }

 async function insertMegye(data)
 {
    try{
        const [rows] = await pool.query('insert into megye (cty_code, cty_name) values (?,?) ', [data.cty_code, data.cty_name]);
        return rows;
    }

    catch(error){
        throw error;
    }
 }
 module.exports = {
    selectMegye,
    selectMegyeId,
    insertMegye,
    
 };