export default function Contact(){
    return(
        <h1>Kapcsilatok</h1>
    )
}