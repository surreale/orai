function Home(){
    return(
        <h1>Nyitólap</h1>
    )
}

export default Home;