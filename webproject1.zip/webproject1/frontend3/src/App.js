import logo from './logo.svg';
import './App.css';
import {BrowserRouter as Router, Routes, Route, Link} from'react-router-dom';
import Home from './Components/Home';
import Contact from './Components/Contact';

function App() {
  return (
  
      <Router>
        <div>

          <ul>
            <li>
              <Link to="/">Home</Link>
        
            </li>
            <li><Link to="/contact">Kapcsolat</Link></li>
          </ul>
       
         <Routes>
          <Route  path="/" element={<Home />} />
          <Route  path="/contact" element={<Contact />} />
         </Routes>
      
    </div>
    </Router>
  );
}

export default App;
