var express = require('express');
var router = express.Router();

let allatok=[
  {
      "id": 1,
      "name": "Oroszlán",
      "description": "Az oroszlán (Panthera leo) a macskafélék családjába tartozik, és a legnagyobb szárazföldi ragadozók közé tartozik. Az oroszlánok társadalmi állatok, és általában csoportokban, úgynevezett 'pride'-ban élnek.",
      "image": "https://cdn.pixabay.com/photo/2024/05/08/17/45/animal-8748794_1280.jpg"
  },
  {
      "id": 2,
      "name": "Tigris",
      "description": "A tigris (Panthera tigris) a legnagyobb macskaféle, amely a Földön él. Az erdőkben, mocsarakban és fűrészelt területeken található meg, és vadászat közben csúszik a fűben.",
      "image": "https://media.istockphoto.com/id/627540386/hu/fot%C3%B3/szib%C3%A9riai-tigris.jpg?s=2048x2048&w=is&k=20&c=ORVzD9dzONg1Tq_fR-1dnmpjvrhQpZPrKBbcXB9HMo4="
  },
  {
      "id": 3,
      "name": "Elefánt",
      "description": "Az elefántok (Elephantidae család) a legnagyobb szárazföldi állatok. Az afrikai és ázsiai elefántok a legismertebb fajai, mindkettő különböző élőhelyeken található meg.",
      "image": "https://cdn.pixabay.com/photo/2023/09/14/19/46/elephant-8253639_960_720.jpg"
  }
]

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});
router.get('/products', function(req, res, next) {
  res.send('Termékek');
})

router.get('/allatok', function(req, res) {
  res.json(allatok);
})
module.exports = router;
