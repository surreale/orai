export const cars = [
    { id: 1, marka: 'Ford', modell: 'Mustang', ev: 2020, kep: 'mustang.jfif' },
    { id: 2, marka: 'BMW', modell: 'X5', ev: 2021, kep: 'x5.jfif'  },
    { id: 3, marka: 'Mercedes', modell: 'S-Class', ev: 2022, kep: 'merci.jfif'  },
];