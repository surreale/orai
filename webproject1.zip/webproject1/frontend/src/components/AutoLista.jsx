import React from 'react';
import { cars } from '../data/cardata';
function AutoKartya({auto}){
    return(
    <div>
    <div>Márka: {auto.marka}</div>
    <div>Modell: {auto.modell}</div>
    <div>Évjárat: {auto.ev}</div>
    <img src={'/images/'+auto.kep} alt="" width={300} />
    <hr></hr>
    </div>);
}
function AutoLista(){
    

    return(
        
        <div>
            <h1>Autók listája</h1>
            {cars.map((car) => <AutoKartya  auto={car} />)}
        </div>
    )
}

export default AutoLista;