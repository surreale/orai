import logo from './logo.svg';
import './App.css';

function App({logo,nev}) {
  
  return (<div className="App">
    <h1>{nev}</h1>
    <img src={logo}></img>
    <button>OK</button>
  </div>)
  ;
}

export default App;
