var config = require('./dbconfig');
 const sql= require("mysql2/promise");
let pool = sql.createPool(config);

async function selectTermek(){
    try{
        const [rows] = await pool.query('SELECT * FROM termek');
        return rows;
    }
    catch(error){
        throw error;
    }
}


async function selectTermekById(id){
    try{
        const [rows] = await pool.query('SELECT * FROM termek where azonosito=?', [id]);
        return rows;
    }
    catch(error){
        throw error;
    }
}
async function deleteTermek(termek,ar){
    try{
        const [rows] = await pool.query('insert into termek (termek,ar) values (?,?)', [termek,ar]);
        return rows;
    }
    catch(error){
        throw error;
    }
}   

async function insertTermek(id){
    try{
        const [rows] = await pool.query('delete from termek where azonosito=? ', [ID]);
        return rows;
    }
    catch(error){
        throw error;
    }
}   

async function update(id, termek, ar){
    try{
        const [rows] = await pool.query('update termek set teermeknev=?, ar=?,where azonosito=? ', [termek,ar,id]);
        return rows;
    }
    catch(error){
        throw error;
    }
}   
module.exports = 
{ 
    selectTermek,
    selectTermekById,
    insertTermek,
    deleteTermek,
    update
};