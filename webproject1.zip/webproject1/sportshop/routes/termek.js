var express= require('express');
var router= express.Router();
var Db= require('../db/dboperations');

/*teljes lista*/
router.get('/', async function(req, res,next) 
{
    try{
        const termekek= await Db.selectTermek();
    res.json(termekek);
    }
    catch(err)
    {
        console.log(err);
        res.status(500).json({hiba: "Hiba a termékek lekérdezésénél",err});
     };
});
//egy termek
router.get('/:azonosito',async function(req, res, next){
    const id= req.params.azonosito;
    const termek= await Db.selectTermekById(id);
    res.json(termek);
  });


//új termék
router.post('/', async function (req,res,next){
    try{
        let adat = req.body;
        if(!adat.ar || !adat.termek){
            res.status(400).json({message: "Hiányos adatok!"})
            return;
        }
        const valasz = await Db.insertTermek(adat.termek, adat.ar);
        res.json(valasz)
    }
    catch(error){
        res.status(500).json({"hiba":error});
    }
});

//termék törlése
router.delete('/:id', async function (req, res, next){
    try{
        let id= req.params.id;
        const valasz= Db.deleteTermek(id);
        if(valasz.affectedRows === 0){
            res.status(404).json({message: "nincs ilyen termék"})
        }
        res.json(valasz);

    }
    catch(error){
        res.status(500).json({"hiba": error})

    }
});

//termék módosítás

router.put('/:id', async function (req, res, next){
    try{
        if(!req.body.ar || !req.body.termek){
            res.status(404).json({message: "Hiányos adatok"})
            return
        }
        let id= req.params.id;
        let valasz= await Db.update(id,req.body.termek, req.body.ar );
        if (valasz.affecRows === 0){
            res.status(404).json({message: "nincs ilyen termék"+id})
        }
        else{
            res.json(valasz);
        }
        

    }
    catch(error){
        res.status(500).json({"hiba": error})

    }
})


module.exports= router;