export default function Footer(){
    return(
        <div style={{backgroundColor:"GrayText"}}>
            Lábléc - kapcsolat
        </div>
    )
}