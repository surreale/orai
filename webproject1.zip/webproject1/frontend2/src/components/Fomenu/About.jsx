import logo from './keo.jpg';
import React from 'react';

export default function About() {
    return (
        <div >
           <h1>Rólunk</h1>
           <img src={logo} alt="Logó" style={{width:'20%',marginLeft:50  }} />
        </div>
    );
}