import React from 'react';

export default function Contact() {
    return (
        <div >
           <h1>Kontakt</h1>
           <h2>Telefonszám: 06301234123</h2>
        </div>
    );
}