import logo from './keo.jpg';

export default function About(){
    return(
       <div>
         <h1>Rólunk</h1>
         <p>
          A Webshop Kft. 2024-ben alakult, és azóta is elkötelezettek vagyunk
          a kiváló minőségű termékek és szolgáltatások iránt. Büszkék vagyunk arra,
          hogy több mint X év tapasztalattal rendelkezünk az iparágban.
        </p>
        <img src={logo} alt="Logó" style={{width:'20%',marginLeft:50  }} />
         <h1>Szolgáltatásaink</h1>
         <ul>
          <li><strong>Szolgáltatás 1:</strong> Rövid leírás</li>
          <li><strong>Szolgáltatás 2:</strong> Rövid leírás</li>
          <li><strong>Szolgáltatás 3:</strong> Rövid leírás</li>
        </ul>

        <footer style={{ textAlign: 'center', marginTop: '50px' }}>
        <h2>Kapcsolat</h2>
        <p>Email: email@example.com</p>
        <p>Telefon: +36 XX XXX XXXX</p>
        <p>Cím: Iroda címe</p>
      </footer>
       </div> 
    )
}