import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css'
import {BrowserRouter as Router, Route, Routes, Outlet, Link, useParams} from "react-router-dom";
import Termeklista from './components/Termeklista';
import Menu from './components/Menu';
import Loginform from './components/Login/LoginForm';


function App() {
  return (
    <Router>
      <Menu/>
      <Routes>
      <Route path="/" element={<Outlet/>}/>
      <Route path="/termeklista" element={<Termeklista/>}/>
      <Route path="/login" element={<Loginform/>}/>
      

    
    </Routes>
    </Router>
  );
}

export default App;
