import {BrowserRouter as Router, route, Routes, Outlet, Link, useParams} from "react-router-dom";

import Termeklista from 