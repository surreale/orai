export default function Nyitolap(){
    return (
        <div>
            <h1>Sport Shop nyitó oldal</h1>
        </div>
    )
}