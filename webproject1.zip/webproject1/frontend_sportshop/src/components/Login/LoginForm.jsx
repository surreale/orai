import {useState} from "react"
import  axios from 'axios';
export default function Loginform(){

    const [email,setEmail] = useState('');
    const [password,setPassword] = useState('');
    const [message,setMessage] = useState('');


    const handleLogin = async () => { setMessage('Bejelentkezés folyamatban'); console.log({email,password}); 
        try{
            const response =  await axios.post('http://localhost:8090/users/login', { email, password});
            if(response.data.token){
                setMessage('Válasz OK'+response.data.token);
                localStorage.setItem('token', response.data.token);
            }

            else{
                setMessage('Válasz hiba');
            }
        }
        catch(error){
            setMessage(error.message);
            
        }
    }
        
    return(
        <>
        <h1>Bejelentkezés</h1>
        <div>
            <label>Email cím:</label>
            <input type="text" value={email} onChange={ (e) => {setEmail(e.target.value)}} />
        </div><br />
        <div>
            <label>Jelszó:</label>
            <input type="password" value={password} onChange={ (e) => {setPassword(e.target.value)}} />
        </div><br />
        <button onClick={handleLogin}>Bejelentkezés</button> 
        <div>

           {message} 
        </div>
        
        
        </>
    )
}