﻿using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace konyv
{
    public class Szerzo
    {
        public int szazon;
        public string sznev;
        public int szul;
        public int hal;
        public string nemzet;
    }

    public class Konyv
    {
        public int kazon;
        public string cim;
        public int szerzoazon;
        public int helyezes;
    }
    public partial class MainWindow : Window
    {
        List<Konyv> konyvek = new List<Konyv>();
        List<Szerzo> szerzok = new List<Szerzo>();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void kereses_Click(object sender, RoutedEventArgs e)
        {
            legjobbLista.Items.Clear();
            // 6. feladat

            int db = Convert.ToInt32(legjobb.Text);

            for (int i = 1; i <= db; i++)
            {
                for (int j = 0; j < konyvek.Count; j++)
                {
                    if (konyvek[j].helyezes == i)
                    {
                        legjobbLista.Items.Add($"{i}.\t{konyvek[j].cim}");
                        break;
                    } 
                }
            }
        }

        private void AdatBetolt(object sender, RoutedEventArgs e)
        {
            using (StreamReader sr = new StreamReader("konyv.txt"))
            {
                while (!sr.EndOfStream)
                {
                    string[] sor = sr.ReadLine().Split(';');
                    Konyv k = new Konyv();
                    k.kazon = Convert.ToInt32(sor[0]);
                    k.cim = sor[1];
                    k.szerzoazon = Convert.ToInt32(sor[2]);
                    k.helyezes = Convert.ToInt32(sor[3]);

                    konyvek.Add(k);
                }
            }

            using (StreamReader sr2 = new StreamReader("szerzo.txt"))
            {
                while (!sr2.EndOfStream)
                {
                    string[] sor = sr2.ReadLine().Split(';');
                    Szerzo sz = new Szerzo();
                    sz.szazon = Convert.ToInt32(sor[0]);
                    sz.sznev = sor[1];
                    sz.szul = Convert.ToInt32(sor[2]);
                    if (sor[3] == "NULL") sz.hal = 0;
                    else sz.hal = Convert.ToInt32(sor[3]);
                    sz.nemzet = sor[4];

                    szerzok.Add(sz);
                }
            }

            //  3. feladat

            List<string> szerzonev = new List<string>();

            for (int i = 0; i < szerzok.Count; i++)
            {
                szerzonev.Add(szerzok[i].sznev);
            }
            szerzonev.Sort();

            for (int i = 0; i < szerzonev.Count; i++)
            {
                nev.Items.Add(szerzonev[i]);
            }
        }

        private void nev_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string aktnev = nev.SelectedItem.ToString();
            int aktszerzoazon = 0;

            for (int i = 0; i < szerzok.Count; i++)
            {
                if (aktnev == szerzok[i].sznev)
                {
                    aktszerzoazon = szerzok[i].szazon;
                    szulEv.Content = Convert.ToInt32(szerzok[i].szul);
                    if (Convert.ToInt32(szerzok[i].hal) == 0) halEv.Content = "-";
                    else halEv.Content = Convert.ToInt32(szerzok[i].hal);
                    nemz.Content = szerzok[i].nemzet;
                    break;
                }
            }

            konyvLista.Items.Clear();
            // 5. feladat

            for (int i = 0; i < konyvek.Count; i++)
            {
                if (konyvek[i].szerzoazon == aktszerzoazon)
                {
                    konyvLista.Items.Add($"{konyvek[i].helyezes}\t{konyvek[i].cim}");
                }
            }
        }
    }
}