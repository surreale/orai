import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import axios from 'axios';  
import { useState, useEffect } from 'react';
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
import {Container, Row, Col} from 'react-bootstrap';
//https://fakestoreapi.com/products

function App() {
  const [data, setdata] = useState([]);
  const [errormsg, seterrormsg] = useState([""]);

  async function fechData(){
    try{
      const valasz = await axios.get("https://fakestoreapi.com/products");
      setdata(valasz.data);
    }
    catch(error){
      seterrormsg(error);
    }
    
  }

  useEffect(()=>{
    fechData();
  }, []);


  return (
    <div>

    <h1>Terméklista</h1>
    {
    <Container fluid>
      <Row>

    {
    data.map((adat) => (
      <Col xs={12} sm={6} md={4} lg={2} key={adat.id} className="d-flex justfy-content-center my-3">
      <Card style={{ width: '18rem' }}>
      <Card.Img variant="top" src={adat.image} />
      <Card.Body>
        <Card.Title>{adat.title}</Card.Title>
        <Card.Title>{"Ár: "+adat.price+"$"}</Card.Title>
        <Card.Text>
          {adat.description}
        </Card.Text>

        <Button variant="primary">Kosárba</Button>
      </Card.Body>
    </Card>
    </Col>) )
    }
    </Row>
    </Container>
    }
    
    </div>
  );
}

export default App;
