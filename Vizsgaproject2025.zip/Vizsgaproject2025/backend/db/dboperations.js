var config = require("./dbconfig");
const sql = require('mysql2/promise');

let pool = sql.createPool(config);

async function selectOra() {
    try {
        const [rows] = await pool.query('select * from ora')
        return rows;
    } catch (error) {
        throw error
    }
}

module.exports = {
    selectOra
}