var express = require('express');
var router = express.Router();
var Db = require('../db/dboperations');

router.get('/', async function(req, res, next) {
  try{
    let ora = await Db.selectOra();
  res.json(ora);
}
catch(error) {
  res.status(500).send('Szerver hiba!');
  console.log(error);
}
});

module.exports = router;
