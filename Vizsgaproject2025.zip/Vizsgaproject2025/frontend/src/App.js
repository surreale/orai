import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Menu from './components/Menu';

function App() {
  return (
    <>
    <Menu />
      <h1>Vizsga frontend</h1>
      <img src = "http://localhost:8080/images/background.jpg" alt="Óra" />
    </>
  );
}

export default App;
