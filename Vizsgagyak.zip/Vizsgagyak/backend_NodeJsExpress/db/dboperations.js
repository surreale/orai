const config = require('./dbconfig');
const sql = require('mysql2/promise');

let pool = sql.createPool(config);
//lekérés
async function selectTermek() {
    try{ 
     const [rows] = await pool.query('select * from termek');
     return rows;
    }
    catch(error){
     throw error;
    } 
 }

//hozzáadás
async function insertTermek(nev,ar,szin) {
    try{ 
     const [rows] = await pool.query('insert into termek (nev,ar,szin) values (?,?,?)', [nev,ar,szin]);
     return rows;
    }
    catch(error){
     throw error;
    } 
 }

 //termék törlése
 async function deleteTermek(id) {
    try{ 
     const [rows] = await pool.query('delete from termek where id=?', [id]);
     return rows;
    }
    catch(error){
     throw error;
    } 
 }

 //termék módosítás

 async function updateTermek(id,nev,ar,szin) {
    try{ 
     const [rows] = await pool.query('update termek set nev=?,ar=?,szin=? where id=? ', [nev,ar,szin,id]);
     return rows;
    }
    catch(error){
     throw error;
    } 
 }



module.exports = {
    selectTermek,
    insertTermek,
    deleteTermek,
    updateTermek
}