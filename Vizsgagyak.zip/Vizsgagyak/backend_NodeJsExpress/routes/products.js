var express = require('express');
var router = express.Router();
var Db = require('../db/dboperations');

//lekérdezés

router.get('/termek', async function(req, res, next) {
 try{
  const termek = await Db.selectTermek();
  res.json(termek);
 }
 catch(error){
  console.log(error);
//  res.status(500).send('Szever hiba!');
res.status(500).json({
    message: 'Szerver hiba!',
    error: error.message || error,  
  });
 }
});

//hozzáadás
router.post('/termek', async function(req, res, next) {
    try{
     const {nev, ar, szin}= req.body;
     if(!nev || !ar || !szin){
        return res.status(400).json({message: 'Hiányzó vagy hibás adatok'});
     }
     const result = await Db.insertTermek(nev,ar,szin);
     res.status(201).json(result);
    }
    catch(error){
     console.log(error);
   
   res.status(500).json({
       message: 'Szerver hiba!',
       error: error.message || error,  
     });
    }
   });

   //termék törlése

   router.delete('/termek/:id', async function(req, res, next) {
    try{
    const id= req.params.id;
     const termek = await Db.deleteTermek(id);
     if(termek.affectedRows===0){
        return res.status(404).json({message: 'Termék nem található'});
     }
     else{
        res.json(termek);
     }
     
    }
    catch(error){
     console.log(error);
   //  res.status(500).send('Szever hiba!');
   res.status(500).json({
       message: 'Szerver hiba!',
       error: error.message || error,  
     });
    }
   });

   //termék módosítása

   router.put('/termek/:id', async function(req, res, next) {
    try{
     const id= req.params.id;
     const {nev, ar, szin}= req.body;
     if(!nev || !ar || !szin){
        return res.status(400).json({message: 'Hiányzó vagy hibás adatok'});
     }
     const result = await Db.updateTermek(id,nev,ar,szin);
     if(result.affectedRows===0){
        return res.status(404).json({message: 'Termék nem található'});
     }
     else{
        res.json(result);
     }
    }
    catch(error){
     console.log(error);
   
   res.status(500).json({
       message: 'Szerver hiba!',
       error: error.message || error,  
     });
    }
   });

module.exports = router;
