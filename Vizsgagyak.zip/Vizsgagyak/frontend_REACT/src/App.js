import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import {BrowserRouter as Router, Routes, Route, Link} from 'react-router-dom';
import Home from './components/Home';
import About from './components/About';
import Lista from './components/Lista';



function App() {
  return (
    <>
     <Router>
      <nav>
          <Link className="button-link" to="/">Main</Link>
          <Link className="button-link" to="/about">About</Link>
          <Link className="button-link" to="/lista">Lista</Link>
      </nav>
      <Routes>
        <Route path="/" element = {<Home/>}/>
        <Route path="/about" element = {<About/>}/>
        <Route path="/lista" element = {<Lista/>}/>
      </Routes>
     </Router>
    </>
  );
}

export default App;
