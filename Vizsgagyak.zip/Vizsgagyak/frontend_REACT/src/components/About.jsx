import logo from './teleki.png';
export default function About(){
    return(
        <div className="container">
            <h1>About</h1>
            <img src={logo} alt="Teleki logo style={{width: '200px, height: 'auto'"/>

            <div>
                <p>Első mondat.</p>
                <p>Második mondat.</p>

            </div>
        </div>
    );
}