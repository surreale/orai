
import React, {useState, useEffect} from 'react';
import axios from 'axios';

export default function Lista(){
   const [data, setData]= useState([]);
   const [loading, setLoading]= useState(true);

   async function fetchData(){
    try{
        const response = await axios.get('http://localhost:8080/products');
        setData(response.data);
        setLoading(false);
    }
    catch(error){
        console.error('Error fetching data:', error);
        setLoading(false)
    }
   }

   useEffect(() => {
    fetchData();
   }, []);
   
   
   
    return(
        <div className="container">
            <h1>Lista</h1>
            {data.map(
                (item) => <div>{item.name}</div>
            )}
        </div>
    );
}